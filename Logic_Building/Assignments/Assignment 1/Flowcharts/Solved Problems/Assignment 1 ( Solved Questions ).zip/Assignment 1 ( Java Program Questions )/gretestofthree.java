public class gretestofthree{
	public static void main(String[] args){
	int a = 12;
	int b = 25;
	int  c = 24;
	if(a>b && a>c){
		System.out.println("a is greater than b, c");
	}
	else if(b>a && b>c){
		System.out.println("b is greater than a, c");
	}
	else{
		System.out.println("c is greater than a, b");
	}
}
}
class oddeven{
public static void main(String args[]){
int n=14;
if(n%2==0){
System.out.println("number is even");
}
else {
System.out.println("number is odd");
}

}
}
public class Areaofrectangle{
    public static void main(String[] args) {
        
        int Hight = 5; 
	int Width = 3;
        int area = Hight * Width;

        System.out.println("The Area of rectangle is: " + area);
    }
}
public class negative{
	public static void main(String[] args){
		int n = -15;
		if(n<0){
			System.out.println("The given number is negative");
			}
		else{
			System.out.println("the given number is positive");
			}
}
}
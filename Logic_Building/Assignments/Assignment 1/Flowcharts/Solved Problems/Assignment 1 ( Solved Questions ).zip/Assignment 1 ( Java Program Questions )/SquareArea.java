public class SquareArea {
    public static void main(String[] args) {
        
        int side = 5; 
        int area = side * side;

        System.out.println("The area of the square with side length " + side + " is: " + area);
    }
}
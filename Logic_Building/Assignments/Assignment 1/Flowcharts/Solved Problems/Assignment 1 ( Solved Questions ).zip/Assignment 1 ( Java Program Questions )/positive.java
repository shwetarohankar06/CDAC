public class positive{
	public static void main(String[] args){
		int a = 15;
		if(a>0){
			System.out.println("The given number is positive");
			}
		else{
			System.out.println("the given number is neagative");
			}
}
}




		
